﻿--abi== 1
--zard==2
--ghermez==3
insert into team(name,cover) values (N'امریکا',1),
(N'ژاپن',2),
(N'ارژانتین',3),
(N'ایران',2);
select * from team;
insert into player(first_name, last_name, nashnull_id, team_id)
values
(N'علی', N'فرهانی', '789456', 1),
(N'حسین', N'حاجی جعفری', '123654', 1),
(N'احمد', N'حسینی', '741658', 1),
(N'مهدی', N'عزیزی', '256471', 2),
(N'اکبر', N'امین پور', '789354', 2),
(N'محمد', N'محمدی', '96312', 2),
(N'اصغر', N'زاده اصر', '852147', 3),
(N'بابک', N'بابکی', '932145', 3),
(N'فرهاد', N'فرهادی', '931478', 3),
(N'سیروس', N'سیروسی', '21457', 4),
(N'باقر', N'باقری', '31215', 4),
(N'صادق', N'صادقی زاده', '961476', 4);
select * from player;
insert into game(home_team, gest_team, home_team_goles, gest_team_goles, game_date)
values
(1, 2, 1, 1, '2018-01-01'),
(3, 4, 2, 1, '2018-01-05'),
(1, 2, 3, 1, '2018-01-08'),
(4, 3, 2, 2, '2018-01-12'),
(4, 1, 0, 0, '2018-01-15'),
(2, 3, 1, 0, '2018-01-18');
select * from game;
insert into card(game_id, player_id, card_color, miniut)
values
(1, 49, 1,80),
(1, 50, 2,30),
(2, 55, 1,50),
(4, 59, 2,90),
(5, 58, 1,40),
(5, 58, 1,70),
(5, 58, 2,70),
(6, 53, 1,15);
select * from card;

select COUNT(*) from game;

select COUNT(*) from card where card_color=2;

select team1.name, team2.name, game.game_date 
from team as team1 join game on team1.id = game.home_team
join team as team2 on team2.id = game.gest_team
where team1.name = N'امریکا';

select team1.name, team2.name, game.game_date , game.home_team_goles , game.gest_team_goles
from team as team1 join game on team1.id = game.home_team
join team as team2 on team2.id = game.gest_team
where game.home_team_goles= game.gest_team_goles;

select * from team where cover = 2;

select game.id, game.game_date, team1.name, team2.name, team1.cover, team2.cover
, game.home_team_goles, game.gest_team_goles
from team as team1 join game on team1.id = game.home_team
join team as team2 on team2.id = game.gest_team
where 
(game.gest_team_goles > game.home_team_goles
and game.gest_team in (select id from team where cover = 2))
or 
(game.gest_team_goles < game.home_team_goles
and game.home_team in (select id from team where cover = 2));

select team.name, count(*) from
player join team on
player.team_id = team.id
 group by team.name;

 select team_id , COUNT(*) from player group by player.team_id;